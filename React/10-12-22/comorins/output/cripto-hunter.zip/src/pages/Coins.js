import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useSelector ,useDispatch } from 'react-redux';
import { getSigleCoin , getChartData} from '../redux/slices/coinSlice';
import parse from 'html-react-parser';
import {Line} from 'react-chartjs-2'
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../firebase/config';
import '../App.css';


const Coins = () => {

  const {id} = useParams()

  const {userData,watchList,IsLogged} = useSelector((state) => state.UserSlice)
  const {SingleCoinData,ChartData} = useSelector((state) => state.CoinSlice)
  const {Currency,Symbol} = useSelector((state) => state.HomeSlice)
  const [Days,setDays] = useState(1)

  const dispatch =useDispatch()

  useEffect(() =>{
    dispatch(getSigleCoin(id));
  },[id])

  useEffect(() =>{
    dispatch(getChartData(Currency,Days,id))
  },[Currency,Days])

  let numberWithCommas = (price) => price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',') ;

  const addToWatchList = async() =>{
    if(userData){
    let coinRef = doc(db,'watchlist',userData.uid)
    try{
      await setDoc(coinRef,{
        coins: watchList ? [...watchList,SingleCoinData.name] : [SingleCoinData.name]
      })
    }
    catch(error){

    }
  }
  else{
    alert('you should login before add to watchlist')
  }
  }

  const removeFromWatchList = async() =>{
    let coinRef = doc(db,'watchlist',userData.uid)
    try{
      await setDoc(coinRef,{
        coins: watchList.filter((list) => list !== SingleCoinData.name),
      },
      {merge: "true"})
      alert(`${SingleCoinData.name} is removed from watchlist`)
    }
    catch(error){
      console.log(error)
    }
  }

  return (
    <>
    {SingleCoinData && (
      <div className='row m-0 mt-1'>
        <div className='col-3 text-white p-3 banner-alignment border-end'>
          <img src={SingleCoinData?.image.large} />
          {/* <label className="fw-bold fs-1 text-uppercase text-gold">{SingleCoinData?.symbol}</label> */}
          <label className="fw-bold display-4 text-gold">{SingleCoinData?.name}</label> 
          <p className='para font-family my-2'>{parse(SingleCoinData.description.en.split('. ')[0])}</p>
          <div className='d-flex flex-column'>
            <span className='fw-semibold fs-4 py-2'>Rank: <span className='fw-normal fs-5'>{SingleCoinData.market_cap_rank}</span></span>
            <span className='fw-semibold fs-4 py-2'>Current Price: <span className='fw-normal fs-5'>{Symbol}{numberWithCommas(SingleCoinData.market_data.current_price[Currency.toLowerCase()])}</span></span>
            <span className='fw-semibold fs-4 py-2'>Market Cap: <span className='fw-normal fs-5'>{Symbol}{SingleCoinData.market_data.market_cap[Currency.toLowerCase()].toString().slice(0,-6)}M</span></span>
          </div>
          {watchList.includes(SingleCoinData.name) ?
            <button className='btn btn-danger w-100 py-2 mt-4' onClick={removeFromWatchList}>Remove Form WatchList </button>:
            <button className='btn btn-warning w-100 py-2 mt-4' onClick={addToWatchList}>Add to watchlist</button>
          }
        </div>
      <div className='d-flex justify-content-center align-items-center col-9 p-2 flex-column'>
        {!ChartData.length > 0 ? (
        <div className='text-center mt-5'>
          <div className="spinner-border text-warning dispaly-1" role="status">
              <span className="visually-hidden">Loading...</span>
          </div>
        </div>
        ): (
          <>
          <Line data={{

            labels:ChartData.map((details) =>{
              let date= new Date(details[0])
              let time= date.getHours() > 12 ? `${date.getHours() - 12}:${date.getMinutes()}PM`:`${date.getHours()}:${date.getMinutes()}AM`

              return Days=== 1 ? time : date.toLocaleDateString()
            }),
            datasets:[{
              data:ChartData.map((details) => details[1]),
              label:`price (Past ${Days} Days) in ${Currency}`,
              borderColor:"#EEBC1D",

            }],
          }}
          options={{
            elements:{
              point:{
                radius:1,
              }
            }
          }}
          />
          </>
        )}
        <div className='d-flex justify-content-around w-100 my-3'>
          <button className='btn btn-warning btn-width' onClick={() => setDays(1)}>1 Day</button>
          <button className='btn btn-warning btn-width' onClick={() => setDays(30)}>1 Month</button>
          <button className='btn btn-warning btn-width' onClick={() => setDays(90)}>3 Months</button>
          <button className='btn btn-warning btn-width' onClick={() => setDays(365)}>1 year</button>
        </div>
      </div>
    </div>
    )}
    </>
  )
}

export default Coins
