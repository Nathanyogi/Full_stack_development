import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth'

import { getFirestore } from 'firebase/firestore';



const firebaseConfig = {
  apiKey: "AIzaSyAuBTPFL_Gouky9enVSytoFxLr0Cz8nmqA",
  authDomain: "crypto-hunter-406f6.firebaseapp.com",
  databaseURL: "https://crypto-hunter-406f6-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "crypto-hunter-406f6",
  storageBucket: "crypto-hunter-406f6.appspot.com",
  messagingSenderId: "885285832156",
  appId: "1:885285832156:web:43fcef787cffef28c1bb19"
};


const app = initializeApp(firebaseConfig);

const auth = getAuth(app);

const db = getFirestore(app)


export {app , auth , db}