import MainRoutes from "./MainRoutes";
import './App.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import "bootstrap/dist/js/bootstrap.min.js";
import "react-alice-carousel/lib/alice-carousel.css";
import { app } from './firebase/config';


function App() {
  return (
    <div className="app">
      <MainRoutes />
    </div>
  );
}

export default App;
