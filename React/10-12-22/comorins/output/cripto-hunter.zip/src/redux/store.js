import { configureStore} from '@reduxjs/toolkit';
import HomeSlice from '../redux/slices/homeSlice';
import CoinSlice from '../redux/slices/coinSlice';
import UserSlice from '../redux/slices/userSlice';

export const store = configureStore({
    reducer:{
        HomeSlice,
        CoinSlice,
        UserSlice,
    }
})