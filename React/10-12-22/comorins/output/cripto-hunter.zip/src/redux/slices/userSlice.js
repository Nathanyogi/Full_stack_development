import { createSlice } from "@reduxjs/toolkit";
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { auth } from "../../firebase/config";

const initialState = {
    RegisterData:{
        email:'',
        // userName:'',
        password:'',
        confirmPass:''
    },
    LoginData:{
        email:'nathanm4122000@gmail.com',
        password:'4122000'
    },
    IsLogged:false,
    userData:null,
    watchList:[]
}

const UserSilce = createSlice({
    name:"UserSlice",
    initialState,
    reducers:{
        setRegisterData:(state,action) =>{
            state.RegisterData = action.payload
        },
        setLoginData:(state,action) =>{
            state.LoginData = action.payload
        },
        setIsLogged:(state,action) =>{
            state.IsLogged = action.payload
        },
        setUserData:(state,action)=>{
            state.userData = action.payload;
        },
        setWatchList:(state,action)=>{
            state.watchList = action.payload
        }
    }
})

export const RegisterFunc = (password,confirmPass,email) => async(dispatch) =>{
    if(password === confirmPass){
        try{
            await createUserWithEmailAndPassword(auth,email,password)
            dispatch(setRegisterData({email:"",password:'',confirmPass:""}))
        }
        catch(error){
            if (error.code === 'auth/email-already-in-use') {
                alert('Email Already in Use');
            }
        }
    }
    else{
        alert ('Password did not macth')
    }
}

export const LoginFunc = (email,password) => async(dispatch)=>{
    try{
        const {_tokenResponse,user} = await signInWithEmailAndPassword(auth,email,password)
        localStorage.setItem('userData',JSON.stringify({token:_tokenResponse.refreshToken,email:user.email,uid:user.uid}))
        alert('Login successful')
        dispatch(setUserData(JSON.parse(localStorage.getItem('userData'))))
        dispatch(setIsLogged(true))
        dispatch(setLoginData({email:'',password:""}))
    }
    catch(error){
        if(error.code === 'auth/wrong-password'){
            alert('Please check the Password');
        }
        if(error.code === 'auth/user-not-found'){
        alert('Please check the Email');
        }
    }

}


export const {setRegisterData,setLoginData,setIsLogged,setUserData ,setWatchList} = UserSilce.actions;

export default UserSilce.reducer