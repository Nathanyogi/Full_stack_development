import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    Currency:"INR",
    Symbol:"₹",
    Trending:[],
    Search:'',
    CoinList:[],
}

const HomeSlice = createSlice({
    name:"Homeslice",
    initialState,
    reducers:{
        setCurrency:(state,action) =>{
            state.Currency = action.payload
        },
        setSymbol:(state,action) =>{
            state.Symbol = action.payload
        },
        setTrending:(state,action) =>{
            state.Trending = action.payload
        },
        setSearch:(state,action) =>{
            state.Search = action.payload
        },
        setCoinList:(state,action) =>{
            state.CoinList = action.payload
        }
    }
})

export const {setCurrency,setSymbol,setTrending,setSearch,setCoinList} = HomeSlice.actions;

export default HomeSlice.reducer