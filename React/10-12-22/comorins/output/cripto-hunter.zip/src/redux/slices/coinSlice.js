import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const initialState = {
    SingleCoinData:null,
    ChartData:[],
}


const CoinSlice = createSlice({
    name:"CoinSlice",
    initialState,
    reducers:{
        setSingleCoinData:(state,action) =>{
            state.SingleCoinData = action.payload
        },
        setChartData:(state,action) =>{
            state.ChartData = action.payload
        }
    }
});

export const getChartData = (Currency,Days,id)=> async(dispatch) => {
    const {data} = await axios.get(`https://api.coingecko.com/api/v3/coins/${id}/market_chart?vs_currency=${Currency}&days=${Days}`)
    dispatch(setChartData(data.prices))
}

export const getSigleCoin = (id) => async (dispatch) =>{
    const {data} = await axios.get(`https://api.coingecko.com/api/v3/coins/${id}`)
    dispatch(setSingleCoinData(data))
}

export const {setSingleCoinData,setChartData} = CoinSlice.actions

export default CoinSlice.reducer