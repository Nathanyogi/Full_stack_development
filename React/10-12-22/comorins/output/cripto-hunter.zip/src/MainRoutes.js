import React from 'react';
import {  
    Routes,
    Route
} from 'react-router-dom';
import Header from './components/header';
import Coins from './pages/Coins';
import Home from './pages/Home';


const MainRoutes = () => {
  return (
    <>
    <Header />
    <Routes>
        <Route path='/' exact element={<Home />}></Route>
        <Route path='/coins/:id' exact element={<Coins />}></Route>
    </Routes>
    </>
  )
}

export default MainRoutes