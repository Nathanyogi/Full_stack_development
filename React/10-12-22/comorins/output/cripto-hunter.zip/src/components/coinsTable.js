import React, { useEffect, useState } from 'react';
import { useSelector ,useDispatch } from 'react-redux';
import { setSearch ,setCoinList } from '../redux/slices/homeSlice';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import '../App.css';


const CoinsTable = () => {

    const {CoinList,Search,Currency,Symbol} = useSelector((state) => state.HomeSlice)

    const[IsLoad,setIsLoad] = useState(false)
    const[page,setPage] = useState(1)

    const dispatch = useDispatch()
    const Navigate = useNavigate()

    let numberWithCommas =(price) => price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',') ;

    const getCoinsList = async() => {
        setIsLoad(true)
        const {data} = await axios.get(`https://api.coingecko.com/api/v3/coins/markets?vs_currency=${Currency}&order=market_cap_desc&per_page=100&page=1&sparkline=false`);
        dispatch(setCoinList(data))
        setIsLoad(false)
    }


    const searchCoin = () => {
        return  CoinList.filter(
          (coin) =>
            coin.name.toLowerCase().includes(Search) || coin.symbol.toLowerCase().includes(Search)
        );
      };
      
    useEffect(() =>{
        getCoinsList()
    },[Currency])

  return (
        <>
        {IsLoad ? 
        <div className='text-center mt-5'>
            <div className="spinner-border text-warning" role="status">
                <span className="visually-hidden">Loading...</span>
            </div>
        </div>
        :(
        <div className='d-flex justify-content-center container flex-column'>
            <div className='d-flex w-100 flex-column'>
                <h2 className='text-white m-3 text-center font-family'>Cryptocurrency Prices by Market Cap</h2>
                <div className='w-50 m-auto'>
                    <input 
                    type='search' 
                    className='form-control bg-transparent p-3 text-secondary border-gold'
                    placeholder='Search For a Crypto Currency'
                    onChange={(e) => dispatch(setSearch(e.target.value))}/>
                </div>
                <table className='table table-hover my-5'>
                <thead className='table-head py-3'>
                    <tr>
                        <th scope='col'>Coins</th>
                        <th scope='col'>Price</th>
                        <th scope='col'>24H Charge</th>
                        <th scope='col'>Market Cap</th>
                    </tr>
                </thead>
                <tbody className='table-dark'>
                    {searchCoin().slice((page-1)*10,(page-1)*10+10).map((coin)=>(
                        <tr onClick={() => Navigate(`/coins/${coin.id}`)} key={coin.id} className="cursor-pointer">
                            <td scope='row' className='d-flex align-items-center'>
                                <img src={coin.image} height="80" />
                                <h5 className='ms-2'>
                                    <span className='text-white text-uppercase'>{coin.symbol}</span><br/>
                                    <span className='text-white my-1'>{coin.name}</span>
                                </h5>
                            </td>
                            <td className=''>{Symbol}{numberWithCommas(coin.current_price.toFixed(2))}</td>
                            <td className={coin.price_change_percentage_24h >= 0 ? "text-success":"text-danger"}>
                                {coin.price_change_percentage_24h >= 0 && "+"}{coin.price_change_percentage_24h.toFixed(2)}
                                </td>
                            <td>{Symbol}{numberWithCommas(coin.market_cap.toString().slice(0,-6))}M</td>
                        </tr>
                    ))}
                </tbody>
                </table>
            </div>
            <nav aria-label="Page navigation example">
                <ul className="pagination justify-content-center">
                    <li className={page ===1 ? "page-item disabled" : "page-item"}>
                    <label className="page-link bg-dark border-gold" onClick={() => setPage(page -1)}>Previous</label>
                    </li>
                    <li className="page-item"><label className="page-link bg-dark border-gold" onClick={() => setPage(1)}  >1</label></li>
                    <li className="page-item"><label className="page-link bg-dark border-gold" onClick={() => setPage(5)}  >5</label></li>
                    <li className="page-item"><label className="page-link bg-dark border-gold" onClick={() => setPage(10)} >10</label></li>
                    <li className={page ===10 ? "page-item disabled" : "page-item"}>
                    <label className="page-link bg-dark border-gold" onClick={() =>setPage(page + 1)} >Next</label>
                    </li>
                </ul>
            </nav>
        </div>
        )}
      
    </>
  )
}

export default CoinsTable
