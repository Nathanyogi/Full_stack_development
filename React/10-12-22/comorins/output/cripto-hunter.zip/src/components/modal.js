import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setRegisterData , setLoginData ,RegisterFunc , LoginFunc ,setIsLogged,setUserData} from '../redux/slices/userSlice';
import GoogleButton from 'react-google-button';
import { GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { auth } from '../firebase/config';


const Modal = () => {

    const {RegisterData , LoginData} = useSelector((state) => state.UserSlice)

    const { email , password , confirmPass}  = RegisterData

    const dispatch  = useDispatch()

    const googleAuth = new GoogleAuthProvider()

    const signInWithGoogle = async() =>{
        try{
            const  data = await signInWithPopup(auth,googleAuth)
            const {_tokenResponse,user} = data
            alert('Login succcess')
            localStorage.setItem('userData',JSON.stringify({token:_tokenResponse.refreshToken,image:user.photoURL,email:user.email,uid:user.uid}))
            dispatch(setUserData({token:_tokenResponse.refreshToken,image:user.photoURL,email:user.email}))
            dispatch(setIsLogged(true))
        }
        catch(error){
            alert(error)
        }
       
    }

  return (
    <>
      <div className="modal fade" id="exampleModal" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" >
            <div className="modal-dialog modal-dialog-centered">
                <div className="modal-content bg-dark p-2">
                    <div className="d-flex justify-content-between p-2">
                        <div></div>
                        <h1 className="font-family text-white " id="exampleModalLabel">Login Form</h1>
                        <button type="button" className="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div className="modal-body">
                        <div className='container text-center'>
                            <input className='form-control my-4 rounded-0 p-2' placeholder='Email' value={LoginData.email} onChange={(e) => dispatch(setLoginData({...LoginData,email:e.target.value}))}/>
                            <input className='form-control my-4 rounded-0 p-2' placeholder='Password'value={LoginData.password} onChange={(e) => dispatch(setLoginData({...LoginData,password:e.target.value}))}/>
                            <div className='text-center w-75 m-auto'>
                                <button className='btn btn-warning w-100 rounded-0 p-2'type='button' onClick={() => dispatch(LoginFunc(LoginData.email,LoginData.password))}>Login</button>
                                <h4 className='text-light my-2'>(or)</h4>
                                <GoogleButton className='w-100' onClick={signInWithGoogle}/>  
                            </div>
                            <p className='text-white my-2'>Don't have an account?
                                <span className='text-secondary btn text-decoration-underline' 
                                data-bs-target="#exampleModalToggle2" 
                                data-bs-toggle="modal">Register here</span>
                            </p>  
                        </div>
                    </div>
                </div>
            </div>
        </div>
        {/* Register Modal */}
        <div className="modal fade" id="exampleModalToggle2" aria-hidden="true" aria-labelledby="exampleModalToggleLabel2" tabIndex="-1">
            <div className="modal-dialog modal-dialog-centered">
                <div className="modal-content bg-dark p-2">
                    <div className="d-flex justify-content-between p-2">
                        <div></div>
                        <h1 className="font-family text-white " id="exampleModalLabel">Register Form</h1>
                        <button type="button" className="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div className="modal-body">
                        <div className='container'>
                            {/* <input className='form-control my-4' value={userName} placeholder='Username' onChange={(e) => dispatch(setRegisterData({...RegisterData,userName:e.target.value}))}/> */}
                            <input className='form-control my-4' value={email} placeholder='Email'  onChange={(e) => dispatch(setRegisterData({...RegisterData,email:e.target.value}))}/>
                            <input className='form-control my-4' value={password} placeholder='Password'  onChange={(e) => dispatch(setRegisterData({...RegisterData,password:e.target.value}))}/>
                            <input className='form-control my-4' value={confirmPass} placeholder='Confrm-Password'  onChange={(e) => dispatch(setRegisterData({...RegisterData,confirmPass:e.target.value}))}/>
                            <div className='text-center w-50 m-auto'>
                                <button className='btn btn-warning w-100' type="button" onClick={() =>dispatch(RegisterFunc(password,confirmPass,email))}>Register</button>
                                <p className='text-white my-2'>Already have an account?
                                <span className='text-secondary btn text-decoration-underline' 
                                data-bs-target="#exampleModal" 
                                data-bs-toggle="modal">Login here</span>
                                </p>
                            </div>                    
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </>
  )
}

export default Modal
