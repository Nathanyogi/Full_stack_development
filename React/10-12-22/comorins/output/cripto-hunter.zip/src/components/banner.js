import React, { useEffect} from 'react';
import '../App.css';
import banner from '../images/banner2.jpg';
import axios from 'axios';
import { useSelector , useDispatch} from 'react-redux';
import { setTrending } from '../redux/slices/homeSlice';
import AliceCarousel from 'react-alice-carousel';
import { Link } from 'react-router-dom';

const Banner = () => {

    const dispatch = useDispatch()

    const {Currency,Trending,Symbol} = useSelector((state) => state.HomeSlice)


    let numberWithCommas =(price) => price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',') ;
    useEffect(() =>{
        getTrendingCoins()
    },[Currency])


    const getTrendingCoins = async() =>{
        const {data} = await axios.get(`https://api.coingecko.com/api/v3/coins/markets?vs_currency=${Currency}&order=gecko_desc&per_page=10&page=1&sparkline=false&price_change_percentage=24h`);
        dispatch(setTrending(data))
    }

    const responsive = {
        0:{
            items:2
        },
        512:{
            items:4
        }
    }

    const items = Trending.map((coins) =>{

        let profit = coins.price_change_percentage_24h >= 0

        return(
            <Link to={`coins/${coins.id}`} className="banner-alignment text-decoration-none text-white">
                <img src={coins.image} alt={coins.name} height='80' className='mb-2' />
                <span className='mb-2 fw-semibold'>{coins.symbol}<span className={profit > 0 ? "text-success ms-3" : "text-danger ms-3"}>{profit && '+'}{coins.price_change_percentage_24h.toFixed(2)}%</span></span>
                <span className='fw-bold fs-4 text-gold'>{Symbol}{numberWithCommas(coins.current_price.toFixed(2))}</span>
            </Link>
        )
    })


  return (
    <div className="banner" style={{backgroundImage:`url(${banner})`}}>
        <div className='banner-alignment h-50'>
            <h1 className='text-uppercase fw-bold text-white display-2'>Crypto hunter</h1>
            <p className='text-capitalize text-secondary'>get all the info regarding your favorite crypto currency</p>
        </div>
        <div className='carosal w-75 h-50 banner-alignment'>
            <AliceCarousel 
                mouseTracking
                infinite
                autoPlayInterval={1000}
                animationDuration={1500}
                disableDotsControls
                disableButtonsControls
                responsive={responsive}
                autoPlay
                items={items}
            />
        </div>
    </div>
  )
}

export default Banner
