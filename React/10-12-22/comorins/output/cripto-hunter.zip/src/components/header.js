import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {useSelector,useDispatch} from 'react-redux';
import { setCurrency ,setSymbol } from '../redux/slices/homeSlice';
import {setIsLogged, setUserData ,setWatchList} from '../redux/slices/userSlice';
import Modal from './modal';
import '../App.css';
import { db } from '../firebase/config';
import { doc, onSnapshot, setDoc } from 'firebase/firestore';

const Header = () => {


    const {Currency,CoinList,Symbol} = useSelector((state) => state.HomeSlice);
    const {IsLogged ,userData , watchList} = useSelector((state) => state.UserSlice);

    const dispatch  = useDispatch()

    useEffect(() =>{
        changeSymbol();
    },[Currency])

    useEffect(() =>{
      if(userData){
        let coinRef = doc(db,'watchlist',"GX7PCE9wStOdGYzXHjWdtCTD3fw2");
        const unsubscribe = onSnapshot(coinRef,(coin)=>{
          if(coin.exists()){
            dispatch(setWatchList(coin.data().coins))
          }
          else{
            console.log('coin is not exists')
          }
        })
        return () =>{
          unsubscribe();
        }
      }
    },[userData])

    
    useEffect(() =>{
        const userdetails = JSON.parse(localStorage.getItem('userData'))
        if(userdetails && userdetails.token){
            dispatch(setIsLogged(true))
            if(userdetails.image && userdetails.image !== null){
              dispatch(setUserData({...userData,image:userdetails.image}))
            }
            else{
              dispatch(setUserData({...userData,email:userdetails.email,uid:userdetails.uid}))
            }
        }
    },[IsLogged])
    
    const changeSymbol = () =>{
        if(Currency === "INR"){
            dispatch(setSymbol("₹"))
        }
        else if(Currency === "USD"){
            dispatch(setSymbol("$"))
        }
    }

    const removeFromWatchList = async(coinName) =>{
      let coinRef = doc(db,'watchlist',userData.uid)
      try{
        await setDoc(coinRef,{
          coins: watchList.filter((list) => list !== coinName),
        },
        {merge: "true"})
        alert(`${coinName} is removed from watchlist`)
      }
      catch(error){
        console.log(error)
      }
    }

  return (
    <nav className="navbar bg-dark p-3 font-family">
        <div className="container-fluid">
            <Link to="/" className="navbar-brand mb-0 text-gold ">Crypto Hunter</Link>
            <select className='bg-transparent rounded py-2 px-3 border-gold text-gold' onChange={(e) => dispatch(setCurrency(e.target.value))}>
                <option className='bg-dark' value={'INR'}>INR</option>
                <option className='bg-dark' value={'USD'}>USD</option>
            </select>


            {!IsLogged ? (<button type="button" className="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal">Login</button>):
            (<>
            {/* side bar */}
            <div className="avatar rounded-circle" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasBottom" aria-controls="offcanvasBottom">
                {userData !== null && userData.image ? <img src={userData.image} className='rounded-circle w-100 '/>:
                <label className='text-white bg-warning avatar-label btn rounded-circle'>{userData.email[0].toUpperCase()}</label>} 
            </div>

            <div className="offcanvas offcanvas-end text-bg-dark" tabIndex="-1" id="offcanvasBottom" aria-labelledby="offcanvasBottomLabel">
              <div className='text-end pt-2 pe-2'>
                <button type="button" className="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
              </div>
              <div className="offcanvas-header justify-content-center flex-column">
                <div className='canvas-head rounded-circle'>
                  {userData !== null && userData.image ? <img src={userData.image} className='rounded-circle w-100'/>:
                  <label className='text-white bg-warning avatar-label rounded-circle display-1'>{userData.email[0].toUpperCase()}</label>}
                </div>
                <h5 className='py-2'>{userData.email}</h5>
              </div>
              <div className="offcanvas-body small">
                <div className='container canvas-body'>
                  <ul className='list-unstyled py-2'>
                    {CoinList.map((coin) =>{
                      if(watchList.includes(coin.name)){
                         return (<li className='d-flex bg-success justify-content-between align-items-center mb-2' key={coin.id}>
                                    <span className='ms-2'>{coin.name}</span>
                                    <span>{Symbol}{coin.current_price}</span>
                                    <button className='btn btn-warning btn-sm rounded-0' onClick={()=>removeFromWatchList(coin.name)}>del</button></li>
                        );
                      }
                    })}
                  </ul>
                </div>
              </div>
              <button className="btn btn-warning rounded-0 my-2 mx-3" type="button" onClick={() => (dispatch(setIsLogged(false)),localStorage.removeItem('userData'),dispatch(setUserData(null)))}>Log0ut</button>
            </div>
            </>)}
            
            <Modal />
        </div>
    </nav>
   
  )
}

export default Header;
