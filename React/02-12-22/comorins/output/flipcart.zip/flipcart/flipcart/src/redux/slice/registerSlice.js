import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const initialState = {
    registerDetails:{
        request :"create_candidate",
        name : "",
        email : "",
        password :"",
        aadhar : "",
        address : "",
        phone:"",
        city:"",
        area:"",
        pin:"",
    },
    registerStatus:false
}

export const RegisterSlice = createSlice({
    name:"RegisterSlice",
    initialState,
    reducers:{
        setRegisterDetails:(state,action) =>{
            state.registerDetails = action.payload
        },
        setRegisterStatus:(state,action) =>{
            state.registerStatus = action.payload
        }
    }
})

export const registerFunc = (registerDetails) =>async(dispatch) =>{
    let {data}  = await axios.post('http://karka.academy/api/action.php',JSON.stringify(registerDetails))
    if(data.status == 'success'){
        alert("Registration Completed");
        dispatch(setRegisterStatus(true))
    }
    else{
        alert('Registration Failed')
    }
}

export const {setRegisterDetails,setRegisterStatus} = RegisterSlice.actions

export default RegisterSlice.reducer