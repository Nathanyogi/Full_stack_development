import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";


 
const initialState = {
    LoggedDetail:{
        IsLogged:false,
        UserName:null,
    },
    LoginLocation:null,
    LoginDetail:{
        request:"candidate_login",
        email:'nathanm412200@gmail.',
        password:'12345',
    },
}

export const MainRouteSlice = createSlice({
    name:"MainRouteSlice",
    initialState,
    reducers:{
        setIsLoggedDetail:(state,action) =>{
            state.LoggedDetail = action.payload
        },
        setLoginLocation:(state,action) =>{
            state.LoginLocation = action.payload
        },
        setLoginDetail:(state,action) =>{
            state.LoginDetail = action.payload
        },
    }

})


export const loggedStatus = (LoginDetail) => async(dispatch) =>{
    let {data} = await axios.post('https://karka.academy/api/action.php',JSON.stringify(LoginDetail))
    if(data.status === 'success'){
        const user= data.data.name;
        localStorage.setItem('flipcartLogin',JSON.stringify({IsLogged:true,UserName:user}))
        dispatch(setIsLoggedDetail({IsLogged:true,UserName:user}))
    }
    else{
        alert('username and password not match')
    } 

}

export const {setIsLoggedDetail,setLoginLocation,setLoginDetail} = MainRouteSlice.actions

export default MainRouteSlice.reducer