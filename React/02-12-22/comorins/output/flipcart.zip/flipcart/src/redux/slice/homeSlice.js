import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    offerProducts:null,
    Allproducts:null,
    showCart:[],
    SearchProduct:'',
}

export const HomeSlice = createSlice({
    name:'HomeSlice',
    initialState,
    reducers:{
        setOfferProducts:(state,action) =>{
            state.offerProducts = action.payload
        },
        setAllproducts:(state,action) =>{
            state.Allproducts = action.payload
        },
        setshowCart:(state,action) =>{
            state.showCart = action.payload
        },
        setSearchProduct:(state,action) =>{
            state.SearchProduct = action.payload
        }
    }
});

export const {setAllproducts,setOfferProducts,setshowCart,setSearchProduct}  =  HomeSlice.actions;

export default HomeSlice.reducer