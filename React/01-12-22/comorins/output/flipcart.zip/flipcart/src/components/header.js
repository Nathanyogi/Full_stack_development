import {Link, useLocation, useNavigate} from 'react-router-dom';
import flipcartLogo from '../img/flipcartlogo.png';
import {useSelector , useDispatch} from 'react-redux'
import {setIsLoggedDetail,setLoginLocation} from '../redux/slice/mainSlice'

function Header(){

    const {LoggedDetail} = useSelector((state) => state.MainRouteSlice)

    const dispatch = useDispatch();
    const location = useLocation();
    const Navigate = useNavigate();

    let login = () =>{
        dispatch(setLoginLocation(location.pathname))
        Navigate('/login');
    }


    let Logout = () =>{
        localStorage.setItem('flipcartLogin',JSON.stringify({IsLogged:false,UserName:''}));
        const LoggedDetail = JSON.parse(localStorage.getItem('flipcartLogin'));
        dispatch(setIsLoggedDetail(LoggedDetail));
    }

    return(
        <>
        <header className="sticky-top">
            <nav className="navbar navbar-expand-lg navbar-light bg-primary justify-content-center align-items-center">
                <img className="navbar-brand ms-2" src={flipcartLogo} width={30} height={45}/>
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
                </button>
                <div className="d-flex ms-5">
                    <input className="form-control me-sm-2 nav-input" id="entry_box" type="search" placeholder="Search for products,brands and more" aria-label="Search" />
                    <button className="btn btn-light my-2 my-sm-0" type="button" >Search</button>
                </div>
                <div className="collapse navbar-collapse nav-content d-flex justify-content-end" id="navbarSupportedContent">
                    <div className="my-lg-0 me-lg-5">
                        <ul className="navbar-nav nav-ul">
                            <li className="nav-item active">
                                <Link to='/' className="nav-link text-white fw-bold" href="index.html">Home</Link>
                            </li>
                            <li className="nav-item dropdown">
                                <a className="nav-link dropdown-toggle text-white fw-bold" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                More
                                </a>
                                <div className="dropdown-menu ">
                                <a className="dropdown-item" href="#">Notification</a>
                                <div className="dropdown-divider"></div>
                                <a className="dropdown-item" href="#">24x7 Customer care</a>
                                <div className="dropdown-divider"></div>
                                <a className="dropdown-item" href="#">Advertice</a>
                                <div className="dropdown-divider"></div>
                                <a className="dropdown-item" href="#">Download App</a>
                                </div>
                            </li>
                            { location.pathname !== '/cart' && <li className="nav-item">
                                <Link to="/cart" className="nav-link text-white d-flex align-items-center fw-bold"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-cart" viewBox="0 0 16 16">
                                    <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l1.313 7h8.17l1.313-7H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
                                    </svg><span>Cart</span>
                                </Link> 
                            </li>}
                        </ul>
                    </div>
                    <div className="d-flex align-items-center me-2">
                        {!LoggedDetail.IsLogged ?  <span id="username" className="bg-dark bg-opacity-75 rounded-circle text-white me-2 p-2">user</span> :  <span id="username" className="bg-warning bg-opacity-75 rounded-circle text-white me-2 p-2">{LoggedDetail.UserName[0]}</span> }
                        {!LoggedDetail.IsLogged ? <button to='/login' className="btn btn-sm btn-light ml-3" onClick={login} >Login</button> : <button className="btn btn-sm btn-light ml-3" onClick={Logout}>Logout</button>}
                    </div>
                </div>
            </nav>
        </header>
        </>
    )
}

export default Header;
