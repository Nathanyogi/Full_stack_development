import React, { useEffect} from "react";
import { useLocation,useNavigate, useParams } from "react-router-dom";
import {useSelector , useDispatch} from 'react-redux';
import {setLoginLocation} from '../redux/slice/mainSlice';
import {setAllproducts} from '../redux/slice/homeSlice'

function Products(){
    const parms = useParams()
    const location = useLocation()
    const Navigate = useNavigate()
    const dispatch = useDispatch()

    const {LoggedDetail} = useSelector((state) => state.MainRouteSlice)
    const {Allproducts} = useSelector((state) => state.HomeSlice)


    if(!localStorage.getItem('cart')){
        localStorage.setItem('cart',JSON.stringify([]))
    }

    let products_detail = JSON.parse(localStorage.getItem("product_list"))

 
    useEffect(() =>{
       dispatch(setAllproducts(products_detail[parms.name]))
    },[parms.name])

    let addToCart = (product) =>{
        let cart = JSON.parse(localStorage.getItem('cart'))
        cart.push(product)
        localStorage.setItem('cart',JSON.stringify(cart))
        Navigate('/cart');   
    }

    let BuyNow = () =>{
        LoggedDetail.IsLogged ? Navigate('/buynow'): Navigate('/login');dispatch(setLoginLocation(location.pathname));
    }

    return(<>
   <div className="container my-5 ">
   {Allproducts && Allproducts.map((detail,index) =>(
        <div key={index+1}>
            <div className='row my-4'>
                <div className="col-4 text-center">
                    <img className="w-100" src={detail.img} style={{height:200}} alt={`img${index + 1}`}/>
                </div>
                <div className="col-6">
                    <h4>{detail.product}</h4>
                    <ul>{detail.specification.map((spec,index) =>(
                        <li key={index}>{spec}</li>
                    ))}</ul>
                </div>
                <div className="col-2">
                    <h2>₹{detail.offer_price}</h2>
                    <span className="text-secondary"><s>₹{detail.original_price}</s></span><span className="text-success ms-2">{detail.offer}</span>
                    <p>{detail.delivery}</p>
                    <button className='btn btn-warning rounded-0' onClick={BuyNow}>BUY NOW</button>
                    <button className='btn btn-secondary rounded-0 mt-2' onClick={() =>addToCart(detail)}> ADD TO CART </button>
                </div>
            </div>
            <hr />
        </div>
    ))}
   </div>
    </>)
}

export default Products;