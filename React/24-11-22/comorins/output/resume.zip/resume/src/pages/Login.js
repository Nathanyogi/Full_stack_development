import React, { useState , useEffect, useContext} from 'react';
import { Link, useNavigate } from 'react-router-dom';
import UserContext from '../components/usecontext';
import axois from 'axios';


export default function Login(){

    const Navigate = useNavigate()

    const[LoginDetail,setLoginDetail] = useState({
        request:"candidate_login",
        email:'nathanm412200@gmail.',
        password:'12345',
    })

    const value = useContext(UserContext);
    const {IsLogged,setIsLogged,setUserName} = value;

    useEffect(()=>{
        if(IsLogged){
            Navigate('/home')
        }
    },[IsLogged])

    

    let loggedStatus = async() =>{
        let {data} = await axois.post('https://karka.academy/api/action.php',JSON.stringify(LoginDetail))
        if(data.status === 'success'){
            const userName = data.data.name;
            localStorage.setItem('Logindetail',JSON.stringify({status:true,user:userName}));
            const LoggedDetail = JSON.parse(localStorage.getItem('Logindetail'))
            setIsLogged(LoggedDetail.status);
            setUserName(LoggedDetail.user);
        }
        else{
            alert('username and password not match')
            setIsLogged(false)
        }

    }

    return(
        <>
        <div className='container w-50 h-100 py-5'>
            <div className='bg-dark d-flex justify-content-center text-white py-5 rounded w-75 m-auto'>
                <div className='text-center w-75'>
                    <h3 className='fw-bold mb-2 text-uppercase'>Login</h3>
                    <p className='text-white-50 mb-5'>Please enter your email and password!</p>
                    <div className='w-100'>
                        <input className='form-control mb-4' placeholder='Email' value={LoginDetail.email} onChange={(e) => setLoginDetail({...LoginDetail,email:e.target.value})}></input>
                        <input className='form-control mb-4' placeholder='password' value={LoginDetail.password} type='password'  onChange={(e) => setLoginDetail({...LoginDetail,password:e.target.value})}></input>
                    </div>
                    <button className="btn btn-outline-light btn-lg px-5 mb-4" type="button" onClick={loggedStatus}>Login</button>
                    <div>
                        <p className="mb-0">Don't have an account? <Link to="/register" className="text-white-50 fw-bold">Sign Up</Link>
                        </p>
                    </div>
                </div>
            </div> 
        </div>
        </>
    )
}