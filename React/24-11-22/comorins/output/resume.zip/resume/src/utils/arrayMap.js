
 export default function ArrayMap({ResumeData,keys,setResumeData}){
    let remove = (index) =>{
        let newAaary = ResumeData[keys]
        newAaary.splice(index,1)
        setResumeData({...ResumeData,[keys]:[...newAaary]})
    }
    return(<> 
    <table className="table">
        <thead>
            <tr>
                <th scope="col">NO</th>
                <th scope="col">{keys}</th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
        {ResumeData[keys].map( (value,index)=>(
            <tr key = {index}>
                <th scope="row">{index + 1}</th>
                <td>{value}</td>
                <td><button onClick={() =>remove(index)} type="button">remove</button></td>
            </tr>
        ))}
        </tbody>
    </table>
     </>)
    
}

export function ViewArray({viewResume,keys}){
    return(
        <>
            {viewResume[keys].map((item,index)=>(
                <li key={index}>{item}</li>
             ))}
        </>
    )
}

