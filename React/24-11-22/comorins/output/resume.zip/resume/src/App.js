import React from "react"
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import MainRoutes from "./MainRoutes";

export default function App() {
  return (
    <MainRoutes />
  );
}