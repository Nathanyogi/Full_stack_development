
 export default function ArrayMap({ResumeData,keys,setResumeData}){
    let remove = (index) =>{
        let newAaary = ResumeData[keys]
        newAaary.splice(index,1)
        setResumeData({...ResumeData,[keys]:[...newAaary]})
    }
    return(<> 
    {ResumeData[keys].map( (value,index)=>(
        <tr key = {index}>
            <td>{index + 1}</td>
            <td>{value}</td>
            <td><button onClick={() =>remove(index)} type="button">remove</button></td>
        </tr>
    ))}
 </>)
    
}

export function ViewArray({viewResume,keys}){
    return(
        <>
            {viewResume[keys].map((item,index)=>(
                <li key={index}>{item}</li>
             ))}
        </>
    )
}

