import React, { useState } from "react";



export default function Home(){

    const[Resume,setResume] = useState({
        // objective:null,
        // name:null,
        // phone:null,
        // email:null,
        // linked:null,
        course_detail:[],
        skills:[],
        interests:[],
        personal_details:{},
        declaration:null,

    })

    let resumeState = async(key,val) =>{

        let update;
        

    }
    return(
        <>
        {/* nav for from */}
        <nav className="navbar text-white bg-dark justify-content-center">
            <h1>Resume Generator</h1>
        </nav>

        <form className="container w-75 mt-4">
            <textarea className="w-100 mb-2" rows={2} placeholder="Objective" onKeyUp={(e) => setResume({...Resume,objective:e.target.value})}/>
            <div className="row mb-2">
                <div className="col-6">
                    <input placeholder="name" className="form-control" onKeyUp={(e) => setResume({...Resume,name:e.target.value})}/>
                </div>
                <div className="col-6">
                    <input placeholder="Phone" className="form-control" onKeyUp={(e) => setResume({...Resume,phone:e.target.value})}/>
                </div>
                <div className="col-6 mt-2">
                    <input placeholder="email" className="form-control"  type='email' onKeyUp={(e) => setResume({...Resume,email:e.target.value})}/>
                </div>
                <div className="col-6 mt-2">
                    <input placeholder="Linked_in" className="form-control" onKeyUp={(e) => setResume({...Resume,linked:e.target.value})}/>
                </div>
            </div>

            <table>
            <thead>
                <tr>
                    <th className="text-center">#</th >
                    <th className="text-center">course</th >
                    <th className="text-center">year</th >
                    <th className="text-center">Institute</th >
                    <th className="text-center">stream</th >
                    <th className="text-center">Percentage</th >
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td><input className="form-control" onKeyUp={(e) => setResume({...Resume,course_detail:[{course:e.target.value}]})}/></td>
                    <td><input className="form-control" onKeyUp={(e) => setResume({...Resume,course_detail:[{Year:e.target.value}]})}/></td>
                    <td><input className="form-control" onKeyUp={(e) => setResume({...Resume})}/></td>
                    <td><input className="form-control" onKeyUp={(e) => setResume({...Resume})}/></td>
                    <td><input className="form-control" onKeyUp={(e) => setResume({...Resume})}/></td>
                </tr>
                <tr>
                    <td>2</td>
                    <td><input className="form-control" onKeyUp={(e) => setResume({...Resume})}/></td>
                    <td><input className="form-control" onKeyUp={(e) => setResume({...Resume})}/></td>
                    <td><input className="form-control" onKeyUp={(e) => setResume({...Resume})}/></td>
                    <td><input className="form-control" onKeyUp={(e) => setResume({...Resume})}/></td>
                    <td><input className="form-control" onKeyUp={(e) => setResume({...Resume})}/></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td><input className="form-control" onKeyUp={(e) => setResume({...Resume})}/></td>
                    <td><input className="form-control" onKeyUp={(e) => setResume({...Resume})}/></td>
                    <td><input className="form-control" onKeyUp={(e) => setResume({...Resume})}/></td>
                    <td><input className="form-control" onKeyUp={(e) => setResume({...Resume})}/></td>
                    <td><input className="form-control" onKeyUp={(e) => setResume({...Resume})}/></td>
                </tr>
            </tbody>
        </table>
        <div className="row my-2">
            <div className="col">
                <label>SKILLS :</label>
                <input className="form-control mb-1" placeholder="Skill-1" onChange={(e) => setResume({...Resume,skills:[...Resume.skills,e.target.value]})}/>
                <input className="form-control mb-1" placeholder="Skill-2" onChange={(e) => setResume({...Resume,skills:[...Resume.skills,e.target.value]})}/>
                <input className="form-control mb-1" placeholder="Skill-3" onChange={(e) => setResume({...Resume,skills:[...Resume.skills,e.target.value]})} />
                <input className="form-control mb-1" placeholder="Skill-4" onChange={(e) => setResume({...Resume,skills:[...Resume.skills,e.target.value]})}/>
            </div>
            <div className="col">
                <label className="text-uppercase">Interests :</label><br/>
                <input className="form-control mb-1" placeholder="Interest-1" onKeyUp={(e) => setResume({...Resume})}/>
                <input className="form-control mb-1" placeholder="Interest-2" onKeyUp={(e) => setResume({...Resume})}/>
                <input className="form-control mb-1" placeholder="Interest-3" onKeyUp={(e) => setResume({...Resume})}/>
                <input className="form-control mb-1" placeholder="Interest-4" onKeyUp={(e) => setResume({...Resume})}/>
            </div>
        </div>
        <label className="text-uppercase">personal_details:</label>
        <div className="row mb-2">
            <div className="col">
                <input className="form-control mb-1" placeholder="Father's Name" onKeyUp={(e) => setResume({...Resume})}/>
                <input className="form-control mb-1" placeholder="Siblings" onKeyUp={(e) => setResume({...Resume})}/>
                <input className="form-control mb-1" placeholder="DOB" onKeyUp={(e) => setResume({...Resume})}/>
                <input className="form-control mb-1" placeholder="Age" onKeyUp={(e) => setResume({...Resume})}/>
            </div>
            <div className="col">
                <input className="form-control mb-1" placeholder="Father_occupation" onKeyUp={(e) => setResume({...Resume})}/>
                <input className="form-control mb-1" placeholder="Gender" onKeyUp={(e) => setResume({...Resume})}/>
                <input className="form-control mb-1" placeholder="Marital Status" onKeyUp={(e) => setResume({...Resume})}/>
                <input className="form-control mb-1" placeholder="Nationality" onKeyUp={(e) => setResume({...Resume})}/>
            </div>
        </div>
        <textarea className="w-100" rows={2} placeholder="Declaration" onKeyUp={(e) => setResume({...Resume})}/>
        <div className="text-center">
            <button>Create Resume</button>
        </div>
        </form>
        </>
    )
}


