import React, { useState } from "react";
import axois from 'axios';



export default function Home(){

    let my_resume = {
    }

    
    const[ResumeData,setResumeData] = useState({
        request :'create_react_resume',
        user : 'Nathan',
        resume:{},
    })


    let addDetails = (key,value,index=null,indexkey=null) =>{
        let my_resume = {
        }
        
        let key_obj = ["education","project"]
        let key_array = ["skills","interest","computer_literacy"]

        if(index == null && indexkey==null){
            my_resume[key] = value;
        }else if(key_obj.includes(key)){
            if(!my_resume[key]){
                my_resume[key] = []
            }
            if(! my_resume[key][index]){
                my_resume[key][index] = {}
            }
            my_resume[key][index][indexkey] = value
        }else if(key_array.includes(key)){
            if(!my_resume[key]){
                my_resume[key] = []
            }
            my_resume[key][index] = value
        }
        else{
            if(!my_resume[key]){
                my_resume[key] = {}
            }
            my_resume[key][index]= value
        }
    }

    let createResume = async() => {
        setResumeData({...ResumeData,resume:my_resume})
        let {data} = await axois.post('http://karka.academy/api/action.php',JSON.stringify(ResumeData))
        console.log(data)
    }


    return(
        
        <>
        {/* nav for from */}
        <nav className="navbar text-white bg-dark justify-content-center">
            <h1>Resume Generator</h1>
        </nav>

        <form className="container w-75 mt-4">
            <textarea className="w-100 mb-2" rows={2} placeholder="Objective" onKeyUp={(e) =>addDetails('objective',e.target.value)}/>
            <div className="row mb-2">
                <div className="col-6">
                    <input placeholder="name" className="form-control" onKeyUp={(e) =>addDetails('name',e.target.value)}/>
                </div>
                <div className="col-6">
                    <input placeholder="Phone" className="form-control" onKeyUp={(e) => addDetails('phone',e.target.value)}/>
                </div>
                <div className="col-6 mt-2">
                    <input placeholder="email" className="form-control"  onKeyUp={(e) => addDetails('email',e.target.value)}/>
                </div>
                <div className="col-6 mt-2">
                    <input placeholder="Linked_in" className="form-control"  onKeyUp={(e) => addDetails('linked',e.target.value)}/>
                </div>
                <div className="col-6 mt-2">
                    <input placeholder="Role" className="form-control"  onKeyUp={(e) => addDetails('role',e.target.value)}/>
                </div>
            </div>

            <label>Education :</label>
            <table>
            <thead>
                <tr>
                    <th className="text-center">#</th >
                    <th className="text-center">course</th >
                    <th className="text-center">year</th >
                    <th className="text-center">Institute</th >
                    <th className="text-center">stream</th >
                    <th className="text-center">Percentage</th >
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td><input className="form-control" onKeyUp={(e) => addDetails('education',e.target.value,0,'course')}/></td>
                    <td><input className="form-control" onKeyUp={(e) => addDetails('education',e.target.value,0,'year')}/></td>
                    <td><input className="form-control" onKeyUp={(e) => addDetails('education',e.target.value,0,'institute')}/></td>
                    <td><input className="form-control" onKeyUp={(e) => addDetails('education',e.target.value,0,'stream')}/></td>
                    <td><input className="form-control" onKeyUp={(e) => addDetails('education',e.target.value,0,'percentage')}/></td>
                </tr>
                <tr>
                    <td>2</td>
                    <td><input className="form-control" onKeyUp={(e) => addDetails('education',e.target.value,1,'course')}/></td>
                    <td><input className="form-control" onKeyUp={(e) => addDetails('education',e.target.value,1,'year')}/></td>
                    <td><input className="form-control" onKeyUp={(e) => addDetails('education',e.target.value,1,'institute')}/></td>
                    <td><input className="form-control" onKeyUp={(e) => addDetails('education',e.target.value,1,'stream')}/></td>
                    <td><input className="form-control" onKeyUp={(e) => addDetails('education',e.target.value,1,'percentage')}/></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td><input className="form-control" onKeyUp={(e) => addDetails('education',e.target.value,2,'course')} /></td>
                    <td><input className="form-control" onKeyUp={(e) => addDetails('education',e.target.value,2,'year')}/></td>
                    <td><input className="form-control" onKeyUp={(e) => addDetails('education',e.target.value,2,'institute')}/></td>
                    <td><input className="form-control" onKeyUp={(e) => addDetails('education',e.target.value,2,'stream')}/></td>
                    <td><input className="form-control" onKeyUp={(e) => addDetails('education',e.target.value,2,'percentage')}/></td>
                </tr>
            </tbody>
        </table>
        <div className="row my-2">
            <div className="col-6">
                <label>SKILLS :</label>
                <input className="form-control mb-1" placeholder="Skill-1" onChange={(e) =>addDetails('skills',e.target.value,0)}/>
                <input className="form-control mb-1" placeholder="Skill-2" onChange={(e) =>addDetails('skills',e.target.value,1)}/>
                <input className="form-control mb-1" placeholder="Skill-3" onChange={(e) =>addDetails('skills',e.target.value,2)} />
                <input className="form-control mb-1" placeholder="Skill-4" onChange={(e) =>addDetails('skills',e.target.value,3)}/>
            </div>
            <div className="col-6">
                <label className="text-uppercase">Interests :</label><br/>
                <input className="form-control mb-1" placeholder="Interest-1" onKeyUp={(e) =>addDetails('interests',e.target.value,0)}/>
                <input className="form-control mb-1" placeholder="Interest-2" onKeyUp={(e) =>addDetails('interests',e.target.value,1)}/>
                <input className="form-control mb-1" placeholder="Interest-3" onKeyUp={(e) =>addDetails('interests',e.target.value,2)}/>
                <input className="form-control mb-1" placeholder="Interest-4" onKeyUp={(e) =>addDetails('interests',e.target.value,3)}/>
            </div>
            <div className="col-6 mx-auto">
                <label>Computer-literacy</label>
                <input className="form-control mb-1" placeholder="computer-skill-1" onKeyUp={(e) =>addDetails('computer_literacy',e.target.value,0)}/>
                <input className="form-control mb-1" placeholder="computer-skill-2" onKeyUp={(e) =>addDetails('computer_literacy',e.target.value,1)}/>
                <input className="form-control mb-1" placeholder="computer-skill-3" onKeyUp={(e) =>addDetails('computer_literacy',e.target.value,2)}/>
                <input className="form-control mb-1" placeholder="computer-skill-4" onKeyUp={(e) =>addDetails('computer_literacy',e.target.value,3)}/>
            </div>
        </div>
        <label className="text-uppercase">personal_details:</label>
        <div className="row mb-2">
            <div className="col">
                <input className="form-control mb-1" placeholder="Father's Name" onKeyUp={(e) =>addDetails('personal_details',e.target.value,'father_name')}/>
                <input className="form-control mb-1" placeholder="Siblings" onKeyUp={(e) =>addDetails('personal_details',e.target.value,'father_coupation')}/>
                <input className="form-control mb-1" placeholder="DOB" onKeyUp={(e) =>addDetails('personal_details',e.target.value,'DOB')}/>
                <input className="form-control mb-1" placeholder="Age" onKeyUp={(e) =>addDetails('personal_details',e.target.value,'age')}/>
            </div>
            <div className="col">
                <input className="form-control mb-1" placeholder="Father_occupation" onKeyUp={(e) =>addDetails('personal_details',e.target.value,'father_occupation')}/>
                <input className="form-control mb-1" placeholder="Gender" onKeyUp={(e) =>addDetails('personal_details',e.target.value,'gender')}/>
                <input className="form-control mb-1" placeholder="Marital Status" onKeyUp={(e) =>addDetails('personal_details',e.target.value,'marital_status')}/>
                <input className="form-control mb-1" placeholder="Nationality" onKeyUp={(e) =>addDetails('personal_details',e.target.value,'nation')}/>
            </div>
        </div>
        <textarea className="w-100" rows={2} placeholder="Declaration" onKeyUp={(e) =>addDetails('declaration',e.target.value)}/>
        <div className="text-center">
            <button type="button" onClick={createResume}>Create Resume</button>
        </div>
        </form>
        </>
    )
}


